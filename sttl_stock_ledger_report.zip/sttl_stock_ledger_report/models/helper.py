from odoo import models, api


class StockLedgerReportHelper(models.AbstractModel):
    _name = 'stock.ledger.report.helper'
    _description = 'Stock Ledger Report Helper'

    @api.model
    def get_report_data(self, data):
        """
        Main method: loop per selected location to prevent internal transfer cancellation.
        """
        location_ids = data.get('location_ids') or []

        # If no locations selected, return empty
        if not location_ids:
            return []

        report_lines = []
        for loc_id in location_ids:
            single_data = data.copy()
            single_data['location_ids'] = [loc_id]  # Process one location at a time
            single_location_result = self._get_report_data_single_location(single_data)
            report_lines.extend(single_location_result)

        return report_lines

    @api.model
    def _get_report_data_single_location(self, data):
        """
        Original logic preserved but scoped per location.
        """
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        product_ids = data.get('product_ids') or []
        categ_ids = data.get('categ_ids') or []
        location_ids = data.get('location_ids') or []
        report_by = data.get('report_by')

        final_product_ids = []

        if categ_ids:
            category_product_ids = self.env['product.template'].search([
                ('categ_id', 'in', categ_ids)
            ]).mapped('product_variant_ids.id')
        else:
            category_product_ids = []

        if product_ids and category_product_ids:
            final_product_ids = list(set(product_ids).intersection(category_product_ids))
        elif product_ids:
            final_product_ids = product_ids
        elif category_product_ids:
            final_product_ids = category_product_ids

        if (product_ids or categ_ids) and not final_product_ids:
            return []

        base_condition = "sm.date BETWEEN %s AND %s"
        base_params = [start_date, end_date]

        if location_ids:
            base_condition += " AND (sm.location_id = ANY(%s) OR sm.location_dest_id = ANY(%s))"
            base_params += [location_ids, location_ids]

        product_filter = ""
        if final_product_ids:
            product_filter = " AND sm.product_id = ANY(%s)"
            base_params.append(final_product_ids)

        final_where_clause = f"{base_condition}{product_filter}"

        if final_product_ids:
            product_query = f"""
                SELECT DISTINCT pp.id AS product_id
                FROM product_product pp
                JOIN product_template ptmpl ON pp.product_tmpl_id = ptmpl.id
                LEFT JOIN stock_move sm ON sm.product_id = pp.id
                WHERE sm.state = 'done' AND {final_where_clause}
            """
            self.env.cr.execute(product_query, tuple(base_params))
            filtered_product_ids = [r['product_id'] for r in self.env.cr.dictfetchall()]
            if not filtered_product_ids:
                return []
        else:
            self.env.cr.execute(f"""
                SELECT DISTINCT sm.product_id
                FROM stock_move sm
                WHERE sm.state = 'done' AND {base_condition}
            """, tuple(base_params))
            filtered_product_ids = [r['product_id'] for r in self.env.cr.dictfetchall()]

        # Opening stock
        opening_conditions = f"sm.date < %s AND sm.state = 'done' AND sm.product_id = ANY(%s)"
        opening_params = [start_date, filtered_product_ids]

        opening_query = f"""
            SELECT
                sm.product_id,
                sl.id AS location_id,
                sl.name AS location_name,
                COALESCE(SUM(
                    CASE
                        WHEN sl_dest.usage = 'internal' AND sl_src.usage != 'internal' THEN sml.qty_done
                        WHEN sl_src.usage = 'internal' AND sl_dest.usage != 'internal' THEN -sml.qty_done
                        ELSE 0
                    END
                ), 0.0) AS opening_stock_qty
            FROM stock_move sm
            LEFT JOIN stock_move_line sml ON sm.id = sml.move_id
            LEFT JOIN stock_location sl_src ON sm.location_id = sl_src.id
            LEFT JOIN stock_location sl_dest ON sm.location_dest_id = sl_dest.id
            LEFT JOIN stock_location sl ON sm.location_id = sl.id
            WHERE {opening_conditions}
            GROUP BY sm.product_id, sl.id, sl.name
        """
        self.env.cr.execute(opening_query, tuple(opening_params))
        opening_rows = self.env.cr.dictfetchall()

        # Clean opening map
        opening_map = {(r['product_id'], r['location_id']): r['opening_stock_qty'] for r in opening_rows}
        complete_opening_map = {(pid, lid): opening_map.get((pid, lid), 0.0)
                                for pid in filtered_product_ids for lid in location_ids}
        opening_map = complete_opening_map

        # Final stock movement query (unchanged)
        main_query = f"""
            WITH normalized_move AS (
                SELECT
                    sm.date::date AS date,
                    sm.product_id,
                    ptmpl.categ_id,
                    CASE
                        WHEN sm.location_id = ANY(%s) THEN sm.location_id
                        ELSE sm.location_dest_id
                    END AS location_id,
                    CASE
                        WHEN sm.location_id = ANY(%s) THEN sl_src.name
                        ELSE sl_dest.name
                    END AS location_name,
                    sml.qty_done,
                    pt.code AS picking_code,
                    sl_src.usage AS src_usage,
                    sl_dest.usage AS dest_usage,
                    sm.production_id,
                    sm.location_dest_id = ANY(%s) AS is_internal_in,
                    sm.location_id = ANY(%s) AS is_internal_out,
                    sm.raw_material_production_id
                FROM stock_move sm
                LEFT JOIN stock_move_line sml ON sm.id = sml.move_id
                LEFT JOIN stock_picking sp ON sm.picking_id = sp.id
                LEFT JOIN stock_picking_type pt ON sp.picking_type_id = pt.id
                LEFT JOIN stock_location sl_src ON sm.location_id = sl_src.id
                LEFT JOIN stock_location sl_dest ON sm.location_dest_id = sl_dest.id
                LEFT JOIN product_product pp ON sm.product_id = pp.id
                LEFT JOIN product_template ptmpl ON pp.product_tmpl_id = ptmpl.id
                WHERE sm.state = 'done' AND {final_where_clause}
            )
            SELECT
                date,
                product_id,
                categ_id,
                location_id,
                location_name,
                SUM(CASE WHEN picking_code = 'outgoing' AND src_usage = 'internal' AND dest_usage = 'customer' THEN qty_done ELSE 0 END) AS sale_qty,
                SUM(CASE WHEN picking_code = 'incoming' AND src_usage = 'supplier' AND dest_usage = 'internal' THEN qty_done ELSE 0 END) AS purchase_qty,
                SUM(CASE WHEN picking_code = 'incoming' AND src_usage = 'customer' AND dest_usage = 'internal' THEN qty_done ELSE 0 END) AS sale_return_qty,
                SUM(CASE WHEN picking_code = 'outgoing' AND src_usage = 'internal' AND dest_usage = 'supplier' THEN qty_done ELSE 0 END) AS purchase_return_qty,
                SUM(CASE WHEN src_usage = 'transit' AND dest_usage = 'internal' THEN qty_done ELSE 0 END) AS transit_in_qty,
                SUM(CASE WHEN src_usage = 'internal' AND dest_usage = 'transit' THEN qty_done ELSE 0 END) AS transit_out_qty,
                SUM(CASE WHEN src_usage = 'internal' AND dest_usage = 'internal' AND is_internal_in THEN qty_done ELSE 0 END) AS internal_in_qty,
                SUM(CASE WHEN src_usage = 'internal' AND dest_usage = 'internal' AND is_internal_out THEN qty_done ELSE 0 END) AS internal_out_qty,
                SUM(CASE WHEN production_id IS NOT NULL AND raw_material_production_id IS NULL THEN qty_done ELSE 0 END) AS production_in_qty,
                SUM(CASE WHEN production_id IS NULL AND raw_material_production_id IS NOT NULL THEN qty_done ELSE 0 END) AS production_out_qty,
                SUM(CASE WHEN src_usage IN ('inventory', 'inventory_loss') AND dest_usage = 'internal' THEN qty_done ELSE 0 END) AS adjustment_in_qty,
                SUM(CASE WHEN src_usage = 'internal' AND dest_usage IN ('inventory', 'inventory_loss') THEN qty_done ELSE 0 END) AS adjustment_out_qty
            FROM normalized_move
            GROUP BY
                date, product_id, categ_id, location_id, location_name
            ORDER BY date
        """
        main_query_params = [
            location_ids, location_ids,
            location_ids, location_ids,
            start_date, end_date, location_ids, location_ids,
        ]

        if final_product_ids:
            main_query_params.append(final_product_ids)

        self.env.cr.execute(main_query, tuple(main_query_params))
        results = self.env.cr.dictfetchall()

        report_lines = []
        current_opening_map = opening_map.copy()

        for res in results:
            key = (res['product_id'], res['location_id'])
            opening_qty = current_opening_map.get(key, 0.0)

            total_in = sum([
                res.get('purchase_qty', 0.0), res.get('sale_return_qty', 0.0),
                res.get('internal_in_qty', 0.0), res.get('transit_in_qty', 0.0),
                res.get('production_in_qty', 0.0), res.get('adjustment_in_qty', 0.0),
            ])
            total_out = sum([
                res.get('sale_qty', 0.0), res.get('purchase_return_qty', 0.0),
                res.get('internal_out_qty', 0.0), res.get('transit_out_qty', 0.0),
                res.get('production_out_qty', 0.0), res.get('adjustment_out_qty', 0.0),
            ])

            closing_qty = opening_qty + total_in - total_out
            current_opening_map[key] = closing_qty

            product = self.env['product.product'].browse(res['product_id'])
            category = self.env['product.category'].browse(res['categ_id'])
            location = self.env['stock.location'].browse(res['location_id'])

            res.update({
                'product_name': product.name,
                'category_name': category.name,
                'location_name': location.complete_name,
                'opening_qty': opening_qty,
                'closing_qty': closing_qty,
            })

            report_lines.append(res)

        # Sorting
        if report_by == 'location':
            report_lines.sort(key=lambda r: (r['location_name'], r['date'], r['product_id']))
        else:
            report_lines.sort(key=lambda r: (r['date'], r['product_id']))

        return report_lines


# from odoo import models, fields, api
# import logging
#
# _logger = logging.getLogger(__name__)
#
#
# class StockLedgerReportHelper(models.AbstractModel):
#     _name = 'stock.ledger.report.helper'
#     _description = 'Stock Ledger Report Helper'
#
#
#     @api.model
#     def get_report_data(self, data):
#         start_date = data.get('start_date')
#         end_date = data.get('end_date')
#         product_ids = data.get('product_ids') or []
#         categ_ids = data.get('categ_ids') or []
#         location_ids = data.get('location_ids') or []
#
#         # Step 1: Compute filtered product IDs based on product/category filters
#         final_product_ids = []
#
#         if categ_ids:
#             category_product_ids = self.env['product.template'].search([
#                 ('categ_id', 'in', categ_ids)
#             ]).mapped('product_variant_ids.id')
#         else:
#             category_product_ids = []
#
#         if product_ids and category_product_ids:
#             final_product_ids = list(set(product_ids).intersection(category_product_ids))
#         elif product_ids:
#             final_product_ids = product_ids
#         elif category_product_ids:
#             final_product_ids = category_product_ids
#
#         # If filters applied but no matching products — exit early
#         if (product_ids or categ_ids) and not final_product_ids:
#             return "", [], True
#
#         # Base condition for date and location filters (used everywhere)
#         base_condition = "sm.date BETWEEN %s AND %s"
#         base_params = [start_date, end_date]
#
#         if location_ids:
#             base_condition += " AND (sm.location_id = ANY(%s) OR sm.location_dest_id = ANY(%s))"
#             base_params += [location_ids, location_ids]
#
#         # Apply product filter conditionally
#         product_filter = ""
#         if final_product_ids:
#             product_filter = " AND sm.product_id = ANY(%s)"
#             base_params.append(final_product_ids)
#
#
#         # Final WHERE clause reused
#         final_where_clause = f"{base_condition}{product_filter}"
#
#         # Query: Filtered products (if filter is applied)
#         if final_product_ids:
#             product_query = f"""
#                 SELECT DISTINCT pp.id AS product_id
#                 FROM product_product pp
#                 JOIN product_template ptmpl ON pp.product_tmpl_id = ptmpl.id
#                 LEFT JOIN stock_move sm ON sm.product_id = pp.id
#                 LEFT JOIN stock_location sl_src ON sm.location_id = sl_src.id
#                 LEFT JOIN stock_location sl_dest ON sm.location_dest_id = sl_dest.id
#                 WHERE sm.state = 'done' AND {final_where_clause}
#             """
#             self.env.cr.execute(product_query, tuple(base_params))
#             filtered_product_ids = [r['product_id'] for r in self.env.cr.dictfetchall()]
#             if not filtered_product_ids:
#                 return []
#         else:
#             # No product/category filter: just filter by location + date
#             self.env.cr.execute(f"""
#                 SELECT DISTINCT sm.product_id
#                 FROM stock_move sm
#                 LEFT JOIN stock_location sl_src ON sm.location_id = sl_src.id
#                 LEFT JOIN stock_location sl_dest ON sm.location_dest_id = sl_dest.id
#                 WHERE sm.state = 'done' AND {base_condition}
#             """, tuple(base_params))
#             filtered_product_ids = [r['product_id'] for r in self.env.cr.dictfetchall()]
#
#         # Prepare parameters for opening stock query
#         opening_conditions = f"sm.date < %s AND sm.state = 'done' AND sm.product_id = ANY(%s)"
#         opening_params = [start_date]  + [filtered_product_ids]
#
#         # Prepare Opening Stock Query
#         opening_query = f"""
#             SELECT
#                 sm.product_id,
#                 sl.id AS location_id,
#                 sl.name AS location_name,
#                 COALESCE(SUM(
#                     CASE
#                         WHEN sl_dest.usage = 'internal' AND sl_src.usage != 'internal' THEN sml.qty_done
#                         WHEN sl_src.usage = 'internal' AND sl_dest.usage != 'internal' THEN -sml.qty_done
#                         ELSE 0
#                     END
#                 ), 0.0) AS opening_stock_qty
#             FROM stock_move sm
#             LEFT JOIN stock_move_line sml ON sm.id = sml.move_id
#             LEFT JOIN stock_location sl_src ON sm.location_id = sl_src.id
#             LEFT JOIN stock_location sl_dest ON sm.location_dest_id = sl_dest.id
#             LEFT JOIN stock_location sl ON sm.location_id = sl.id
#             WHERE {opening_conditions}
#             GROUP BY sm.product_id, sl.id, sl.name
#         """
#         self.env.cr.execute(opening_query, tuple(opening_params))
#         opening_rows = self.env.cr.dictfetchall()
#
#         # Build opening map
#         opening_map = {(r['product_id'], r['location_id']): r['opening_stock_qty'] for r in opening_rows}
#         complete_opening_map = {(pid, lid): opening_map.get((pid, lid), 0.0)
#                                 for pid in filtered_product_ids for lid in location_ids}
#         opening_map = complete_opening_map
#
#         # Final stock movement query
#         main_query_params = [
#             location_ids,  # 1: sm.location_id = ANY(%s)
#
#
#             location_ids,  # 2: sm.location_dest_id = ANY(%s)
#             location_ids,  # 2: sm.location_dest_id = ANY(%s)
#             location_ids,  # 2: sm.location_dest_id = ANY(%s)
#
#             location_ids,  # 1: sm.location_id = ANY(%s)
#
#             location_ids,  # 5: (sm.location_id = ANY(%s)
#             start_date,  # 3
#             end_date,  # 4
#
#             location_ids,  # 2: sm.location_dest_id = ANY(%s)
#             location_ids,  # 2: sm.location_dest_id = ANY(%s)
#             # start_date,  # 3
#             # end_date,  # 4
#             # location_ids,  # 2: sm.location_dest_id = ANY(%s)
#             #
#             # location_ids,  # 6: sm.location_dest_id = ANY(%s)
#         ]
#         main_query = f"""
#             WITH normalized_move AS (
#                 SELECT
#                     sm.date::date AS date,
#                     sm.product_id,
#                     ptmpl.categ_id,
#                     CASE
#                         WHEN sm.location_id = ANY(%s) THEN sm.location_id
#                         ELSE sm.location_dest_id
#                     END AS location_id,
#                     CASE
#                         WHEN sm.location_id = ANY(%s) THEN sl_src.name
#                         ELSE sl_dest.name
#                     END AS location_name,
#                     sml.qty_done,
#                     pt.code AS picking_code,
#                     sl_src.usage AS src_usage,
#                     sl_dest.usage AS dest_usage,
#                     sm.production_id,
#
#                     CASE
#                         WHEN sm.location_id != sm.location_dest_id
#                              AND sm.location_dest_id = ANY(%s)
#                              AND sm.location_id != ALL(%s)  -- source NOT in selected
#                              AND sl_src.usage = 'internal'
#                              AND sl_dest.usage = 'internal'
#                         THEN TRUE
#                         ELSE FALSE
#                     END AS is_internal_in,
#
#                     CASE
#                         WHEN sm.location_id != sm.location_dest_id
#                              AND sm.location_id = ANY(%s)
#                              AND sm.location_dest_id != ALL(%s)  -- dest NOT in selected
#                              AND sl_src.usage = 'internal'
#                              AND sl_dest.usage = 'internal'
#                         THEN TRUE
#                         ELSE FALSE
#                     END AS is_internal_out,
#
#                     sm.raw_material_production_id
#                 FROM stock_move sm
#                 JOIN res_company rc ON rc.id = sm.company_id
#                 LEFT JOIN stock_move_line sml ON sm.id = sml.move_id
#                 LEFT JOIN stock_picking sp ON sm.picking_id = sp.id
#                 LEFT JOIN stock_picking_type pt ON sp.picking_type_id = pt.id
#                 LEFT JOIN stock_location sl_src ON sm.location_id = sl_src.id
#                 LEFT JOIN stock_location sl_dest ON sm.location_dest_id = sl_dest.id
#                 LEFT JOIN product_product pp ON sm.product_id = pp.id
#                 LEFT JOIN product_template ptmpl ON pp.product_tmpl_id = ptmpl.id
#                 WHERE sm.state = 'done' AND {final_where_clause}
#
#             )
#             SELECT
#                 date,
#                 product_id,
#                 categ_id,
#                 location_id,
#                 location_name,
#                 SUM(CASE WHEN picking_code = 'outgoing' AND src_usage = 'internal' AND dest_usage = 'customer' THEN qty_done ELSE 0 END) AS sale_qty,
#                 SUM(CASE WHEN picking_code = 'incoming' AND src_usage = 'supplier' AND dest_usage = 'internal' THEN qty_done ELSE 0 END) AS purchase_qty,
#                 SUM(CASE WHEN picking_code = 'incoming' AND src_usage = 'customer' AND dest_usage = 'internal' THEN qty_done ELSE 0 END) AS sale_return_qty,
#                 SUM(CASE WHEN picking_code = 'outgoing' AND src_usage = 'internal' AND dest_usage = 'supplier' THEN qty_done ELSE 0 END) AS purchase_return_qty,
#                 SUM(CASE WHEN src_usage = 'transit' AND dest_usage = 'internal' THEN qty_done ELSE 0 END) AS transit_in_qty,
#                 SUM(CASE WHEN src_usage = 'internal' AND dest_usage = 'transit' THEN qty_done ELSE 0 END) AS transit_out_qty,
#                 SUM(CASE WHEN src_usage = 'internal' AND dest_usage = 'internal' AND is_internal_in THEN qty_done ELSE 0 END) AS internal_in_qty,
#                 SUM(CASE WHEN src_usage = 'internal' AND dest_usage = 'internal' AND is_internal_out THEN qty_done ELSE 0 END) AS internal_out_qty,
#                 SUM(CASE WHEN production_id IS NOT NULL AND raw_material_production_id IS NULL THEN qty_done ELSE 0 END) AS production_in_qty,
#                 SUM(CASE WHEN production_id IS NULL AND raw_material_production_id IS NOT NULL THEN qty_done ELSE 0 END) AS production_out_qty,
#                 SUM(CASE WHEN src_usage IN ('inventory', 'inventory_loss') AND dest_usage = 'internal' THEN qty_done ELSE 0 END) AS adjustment_in_qty,
#                 SUM(CASE WHEN src_usage = 'internal' AND dest_usage IN ('inventory', 'inventory_loss') THEN qty_done ELSE 0 END) AS adjustment_out_qty
#             FROM normalized_move
#             GROUP BY
#                 date,
#                 product_id,
#                 categ_id,
#                 location_id,
#                 location_name
#             ORDER BY date
#
#         """
#
#         if final_product_ids:
#             main_query_params.append(final_product_ids)
#
#         self.env.cr.execute(main_query, tuple(main_query_params))
#         results = self.env.cr.dictfetchall()
#
#         # Process results
#         report_lines = []
#         current_opening_map = opening_map.copy()
#         report_by = data.get('report_by')
#
#         for res in results:
#             key = (res['product_id'], res['location_id'])
#             opening_qty = current_opening_map.get(key, 0.0)
#             total_in = sum([
#                 res.get('purchase_qty', 0.0), res.get('sale_return_qty', 0.0),
#                 res.get('internal_in_qty', 0.0), res.get('transit_in_qty', 0.0),
#                 res.get('production_in_qty', 0.0), res.get('adjustment_in_qty', 0.0),
#             ])
#             total_out = sum([
#                 res.get('sale_qty', 0.0), res.get('purchase_return_qty', 0.0),
#                 res.get('internal_out_qty', 0.0), res.get('transit_out_qty', 0.0),
#                 res.get('production_out_qty', 0.0), res.get('adjustment_out_qty', 0.0),
#             ])
#             closing_qty = opening_qty + total_in - total_out
#             current_opening_map[key] = closing_qty
#
#             product = self.env['product.product'].browse(res['product_id'])
#             category = self.env['product.category'].browse(res['categ_id'])
#             location = self.env['stock.location'].browse(res['location_id'])
#
#             res.update({
#                 'product_name': product.name,
#                 'category_name': category.name,
#                 'location_name': location.complete_name,
#                 'opening_qty': opening_qty,
#                 'closing_qty': closing_qty,
#             })
#
#             report_lines.append(res)
#
#         # Optional sorting
#         if report_by == 'location':
#             report_lines.sort(key=lambda r: (r['location_name'], r['date'], r['product_id']))
#         else:
#             report_lines.sort(key=lambda r: (r['date'], r['product_id']))
#
#         return report_lines
